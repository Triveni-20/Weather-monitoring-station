# 🌦️ Weather Monitoring Station (Python)

This is a simple Real-Time Weather Monitoring Station written in Python.
It uses the **OpenWeatherMap API** to fetch current weather for any city.

## Features
- Fetches live weather (temperature, humidity, condition) for any city
- Simple console output with a friendly layout
- Basic error handling for network/API issues

## Requirements
- Python 3.7+
- `requests` library

You can install requirements with:
```
pip install -r requirements.txt
```

## How to use
1. (Optional) Replace the API key in `weather_monitor.py` with your own OpenWeatherMap API key.
2. Open a terminal and navigate to the project folder.
3. Run:
```
python weather_monitor.py
```
4. Enter the city name when prompted, e.g. `Hyderabad` or `London`.

## Notes on API Key security
The provided ZIP contains the API key embedded for convenience. **If you plan to publish the repository publicly on GitHub, it's recommended to remove the key** and use one of these approaches instead:
- Store the key in an environment variable and read it from the code.
- Use a separate `config.py` that's listed in `.gitignore`.
- Use GitHub Secrets for CI/CD usage.

## Created by
**Danaboyina Triveni**
