# weather_monitor.py
# Real-time Weather Monitoring Station (Console)
# Created by: Danaboyina Triveni

import requests

API_KEY = "d6618cfbd38ccd0031db58116a8b03b6"  # <-- Keep this secret. You can replace with your own key.
BASE_URL = "https://api.openweathermap.org/data/2.5/weather"

def kelvin_to_celsius(k):
    return k - 273.15

def fetch_weather(city):
    params = {
        'q': city,
        'appid': API_KEY,
        'units': 'metric'  # returns temperature in Celsius when 'metric' is used
    }
    try:
        resp = requests.get(BASE_URL, params=params, timeout=10)
        resp.raise_for_status()
    except requests.RequestException as e:
        return {'error': f'Network or request error: {e}'}
    try:
        data = resp.json()
    except ValueError:
        return {'error': 'Invalid response from weather service.'}
    if data.get('cod') != 200:
        return {'error': data.get('message', 'Could not fetch weather')}

    main = data.get('main', {})
    weather = data.get('weather', [{}])[0]
    result = {
        'city': data.get('name'),
        'temperature': main.get('temp'),
        'feels_like': main.get('feels_like'),
        'humidity': main.get('humidity'),
        'description': weather.get('description', '').title()
    }
    return result

def pretty_print(weather):
    if 'error' in weather:
        print('Error:', weather['error'])
        return
    print('\n🌦️  Weather Report')
    print('---------------------------')
    print(f"Location : {weather['city']}")
    print(f"Temperature : {weather['temperature']:.1f} °C (Feels like: {weather['feels_like']:.1f} °C)")
    print(f"Humidity : {weather['humidity']}%") 
    print(f"Condition : {weather['description']}\n")

def main():
    print("Welcome to your Weather Monitoring Station 🌤️")
    city = input('Enter city name (e.g., Hyderabad): ').strip()
    if not city:
        print('City name cannot be empty.')
        return
    print('\nFetching weather...')
    weather = fetch_weather(city)
    pretty_print(weather)

if __name__ == '__main__':
    main()
